<?php

namespace App\Http\Controllers;



use App\Interfaces\Areacalculavel;
use App\Models\Circulo;
use App\Models\Quadrado;
use App\Models\Retangulo;
use Illuminate\Http\Request;

class CalculaArea extends Controller
{
    public function calculaArea(Request $request, string $forma)
    {
        $request->validate([
            'lado' => 'required_if:forma,quadrado',
            'base' => 'required_if:forma,retangulo',
            'altura' => 'required_if:forma,retangulo',
            'raio' => 'required_if:forma,circulo',
        ]);

        $area = 0;

        switch ($forma) {
            case 'quadrado':
                $area = (new Quadrado($request->lado))->calculaArea();
                break;
            case 'retangulo':
                $area = (new Retangulo($request->base, $request->altura))->calculaArea();
                break;
            case 'circulo':
                $area = (new Circulo($request->raio))->calculaArea();
                break;
            default:
                return view('error', ['message' => 'Forma geométrica inválida.']);
        }

        return view('resultado', ['area' => $area]);
    }
}