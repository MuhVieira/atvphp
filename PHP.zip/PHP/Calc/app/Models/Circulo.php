<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Circulo extends Model
{
    use HasFactory;
    
        private $raio;
    
        public function __construct($raio) {
            $this->raio = $raio;
        }
    
        public function calculaArea(): float {
            return pi() * $this->raio * $this->raio;
        }
}

