<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;


interface AreaCalculavel {
    public function calculaArea(): float;
}
