<!DOCTYPE html>
<html>
<head>
    <title>Erro</title>
</head>
<body>
    <h1>Erro</h1>
    <p>{{ $mensagem }}</p>
</body>
</html>
