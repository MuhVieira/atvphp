<?php

use App\Http\Controllers\AreaController;

Route::get('/calcular/area/{forma}', [AreaController::class, 'calculaArea'])->name('calcula.area');